//
//  Contato.swift
//  Lista de Contatos
//
//  Created by Matheus Praxedes on 15/04/20.
//  Copyright © 2020 Matheus Praxedes. All rights reserved.
//


import UIKit

class Contato {
    
    var username: String!
    var nome: String!
    var imagem:UIImage!
    
    init (username: String, nome: String){
        self.username = username
        self.nome = nome
        
    }
    
}
