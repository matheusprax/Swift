//
//  ViewController.swift
//  Lista de Contatos
//
//  Created by Matheus Praxedes on 15/04/20.
//  Copyright © 2020 Matheus Praxedes. All rights reserved.
//

import UIKit

class ViewController: UITableViewController {

    var contatos: [Contato] = []
    
  
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        var contato: Contato
        
        contato = Contato(username: "@aliceromero", nome: "Alice Romero")
        contatos.append(contato)
        
        contato = Contato(username: "@caiovibes", nome: "Caio Borges")
        contatos.append(contato)
        
      
        
    }
    /* Numero de linhas que vai retornar*/
    
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    /* Numero de itens que vai retornar, nesse caso a quantidade de contatos*/
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contatos.count
        
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let contato:Contato = contatos (indexPath.row)
        
        
        
    }

}

